class Joinex extends Thread
{  
 public void run()
 {  
  for(int i=1;i<=5;i++)
  {  
   try
   {  
    Thread.sleep(500);  
   }
   catch(Exception e)
   {
	   System.out.println(e);
   }  
   	   System.out.println(i);  
  }  
 }  
public static void main(String args[]){  
	Joinex t1=new Joinex();  
	Joinex t2=new Joinex();  
	Joinex t3=new Joinex();  
 t2.start();  
 try
 {  
  //t2.join(1500);
	 t2.join();//t2 first executed then t1,t3 collapsed(run until die)
 }
 catch(Exception e)
 {
	 System.out.println(e);
}  
  
 t1.start();  
 t3.start();  
 }  
}  