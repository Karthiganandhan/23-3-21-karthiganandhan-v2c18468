public class Threadimp implements Runnable 
{
  public static void main(String[] args) 
  {
    Threadimp obj = new Threadimp();
    Thread thread = new Thread(obj);
  
    System.out.println("This code is outside of the thread");
    thread.start();
  }
  public void run() 
  {
    System.out.println("This code is running in a thread");
  }
}