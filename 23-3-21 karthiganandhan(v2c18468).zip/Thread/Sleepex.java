class Sleepex implements Runnable
{  
 public void run()
 {  
  for(int i=1;i<5;i++)
  {  
    try
    {
    	Thread.sleep(15);
    }
    catch(InterruptedException e)
    {
    	System.out.println(e);
    }  
    System.out.println(i);  
  }  
 }  
 public static void main(String args[]){  
  Sleepex t1=new Sleepex();  
  Sleepex t2=new Sleepex(); 
  
  Thread thread = new Thread(t1);
  Thread thread1 = new Thread(t2);
  
 // thread1.run();//doesnt wait or dont create new task,run in separate task  
  //thread.run(); 
  thread1.start();  
  thread.start(); 
 }  
}  