public class Threadex extends Thread 
{
	static int a;
	static int b;
	
	
  public static void main(String[] args) 
  {
	  Threadex thread = new Threadex();
	  Threadex thread1=new Threadex();
	  thread.setPriority(Thread.MIN_PRIORITY); 
	  thread1.setPriority(Thread.MIN_PRIORITY); 
	 thread1.start();
	  thread.start();
	  a++;
	  while(thread.isAlive()) {
		    System.out.println("Waiting...");
		  }
	  a++;
	  b++;
    System.out.println("This code is outside of the thread"+a+" "+b);
    
  }
  public void run()
  {
	  b++;
    System.out.println("This code is running in a thread"+a+" "+b);
  }
}